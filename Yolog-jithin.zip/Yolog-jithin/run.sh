#!/bin/bash
pm2 scale app +3
