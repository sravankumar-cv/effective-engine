import React from 'react';
import ProviderDashboard from '../components/ProviderDashboard/ProviderDashboard';

export default class ProviderDashboardContainer extends React.Component {
    render() {
        return(
            <ProviderDashboard />
        )
    }
}