import React from 'react';
import ProviderProfile from '../components/ProviderDashboard/ProviderProfile';

export default class ProviderProfileContainer extends React.Component {
    render() {
        return(
            <ProviderProfile />
        )
    }
}