/**
 * @fileoverview Action for user logout.
 */