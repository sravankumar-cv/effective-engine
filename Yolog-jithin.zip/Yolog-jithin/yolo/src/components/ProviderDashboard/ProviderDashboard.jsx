import React from 'react';

export default class ProviderDashboard extends React.Component {
    render() {
        return(
            <div>
                Hey from ProviderDashboard
            </div>
        )
    }
}