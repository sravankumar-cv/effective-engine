import React from 'react';


export default class AdminProfile extends React.Component {
    render() {
        return(
            <div>
                Hey from AdminProfile
            </div>
        )
    }
}